Trojan win32 magic_360.exe
このトロイの木馬は警告がありません
そしてこのファイルを配布しないでください
仮想マシンで実行することをお勧めします。
とんかつより



::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Trojan win32 magic_360.exe
This Trojan has no warnings
And please do not distribute this file!
We recommend that you run it in a virtual machine.
from pork cutlets
 


 




